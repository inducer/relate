print(a)
print(b)
c = a + b
print(c)
